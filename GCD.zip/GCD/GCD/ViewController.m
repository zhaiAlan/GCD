//
//  ViewController.m
//  GCD
//
//  Created by jinxin on 16/5/31.
//  Copyright © 2016年 zhaixingzhi. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UIImageView *iconView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(100, 100, 100, 40);
    button.backgroundColor = [UIColor magentaColor];
    [button setTitle:@"alan" forState:UIControlStateNormal];
    [button setTitle:@"zhaiXingzhi" forState:UIControlStateSelected];
    [button addTarget:self action:@selector(ClickButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    
//    self.iconView.backgroundColor = [UIColor redColor];
//    [self GCDSyncDemo];
    // Do any additional setup after loading the view, typically from a nib.
}
-(void)ClickButton:(UIButton *)button
{
    button.selected = !button.selected;
}
#pragma mark - GCD方法，同步任务的阻塞
-(void)GCDSyncDemo
{
}
#pragma mark - 异步获取图片，获取到后再主线程上修改UI
-(void)GCD
{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSURL * url = [NSURL URLWithString:@"http://avatar.csdn.net/2/C/D/1_totogo2010.jpg"];
        NSData * data = [[NSData alloc]initWithContentsOfURL:url];
        UIImage *image = [[UIImage alloc]initWithData:data];
        if (data != nil) {
            dispatch_async(dispatch_get_main_queue(), ^{
                self.iconView.image = image;
            });
        }
    });

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
